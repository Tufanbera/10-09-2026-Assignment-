"""
Question 7: Daily Expense Tracker
A person records daily expenses in a list. 
Write a function to calculate the total expenses, average daily expense, 
and the days on which expenses exceeded ₹1,000.
"""
Expense=[1200,900,570,800,821]
def media_likes(Expense):
    total_expenses=max(Expense)
    average_expenses=sum(Expense)/len(Expense)
    exceeded_1000=[i for i in Expense if i>1000]

    print(f"total expenses :{total_expenses} \naverage expenses :{average_expenses} \nexceeded 1000 expences:{exceeded_1000}")

media_likes(Expense)