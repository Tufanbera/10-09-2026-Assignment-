"""
Question 5: Social Media Likes
A social media platform stores the number of likes received by five posts 
in a list. Write a function to find the post with the highest likes, 
calculate total likes, and display posts that received at least 100 likes.
"""

likes=[120,90,150,200,321]
def media_likes(likes):
    heighest_likes=max(likes)
    total_likes=sum(likes)
    like_100=[i for i in likes if i>100]

    print(f"Heighest like :{heighest_likes} \ntotal like :{total_likes} \natleast 100 likes:{like_100}")

media_likes(likes)