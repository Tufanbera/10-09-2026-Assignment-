"""
Question 9: Mobile Product Details
An electronics store stores mobile details in a tuple 
containing brand, model, price, and storage capacity. 
Write a function to display the details and 
check whether the mobile price is below ₹30,000.
"""
def Mobile_Product_Details(product):
    brand , model, price,storage_capacity=product
    price_below_30k=lambda x:x<30000
    print(f"Brand name: {brand}")
    print(f"Model name: {model}")
    print(f"Price: {price}")
    print(f"storage_Capacity: {storage_capacity}")
    print(f"price below 30000:{price_below_30k(price)}")

product_details=("Vivo","y20",24000,"64GB")
Mobile_Product_Details(product_details)



    