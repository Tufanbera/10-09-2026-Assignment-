"""
Question 8: Student Registration Record
A college stores a student's roll number, name, course, and semester in a tuple.
 Write a function that displays each field separately and 
 prints the complete student record.
"""
def display_student_record(student):
    roll_number, name, course, semester = student
    print(f"Roll Number: {roll_number}")
    print(f"Name: {name}")
    print(f"Course: {course}")
    print(f"Semester: {semester}")
    print(f"Complete Student Record: {student}")

student_record = (101, "tufan", "Computer Science", 8)
display_student_record(student_record)