"""
Question 1: Student Marks Analysis
A college stores students' marks in a list. 
Write a function that accepts a list of marks and displays the highest mark,
 lowest mark, average mark, and number of students who passed (marks of 40 or above).
"""

def analyze_marks(marks):

    highest_mark = max(marks)
    lowest_mark = min(marks)
    average_mark = sum(marks) / len(marks)
    
    passed_students = 0
    for mark in marks:
        if mark >= 40:
            passed_students += 1

    return {
        "highest_mark": highest_mark,
        "lowest_mark": lowest_mark,
        "average_mark": average_mark,
        "passed_students": passed_students
    }

list_of_marks=[85, 42, 67, 90, 38, 55, 73, 29, 100, 45]
result=analyze_marks(list_of_marks)
print(result)